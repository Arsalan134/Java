import java.util.ArrayList;

public class Morse {
	public static final String d = "*";
	public static final String m = "-";

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<>();
		String text = "Hello World";
		list = convertToMorse(text);

		// Print words of the list
		for (int i = 0; i < list.size(); i++)
			System.out.print(list.get(i) + " ");

	}

	public static ArrayList<String> convertToMorse(String text) {
		ArrayList<String> list = new ArrayList<>();
		for (int i = 0; i < text.length(); i++)
			list.add(morseCharacter(text.charAt(i)));
		return list;
	}

	public static String morseCharacter(char ch) {
		switch (ch) {
			case 'A' :
			case 'a' :
				return d + m;
			case 'B' :
			case 'b' :
				return m + d + d + d;
			case 'C' :
			case 'c' :
				return m + d + m + d;
			case 'D' :
			case 'd' :
				return m + d + d;
			case 'E' :
			case 'e' :
				return d;
			case 'F' :
			case 'f' :
				return d + d + m + d;
			case 'G' :
			case 'g' :
				return m + m + d;
			case 'H' :
			case 'h' :
				return d + d + d + d;
			case 'I' :
			case 'i' :
				return d + d;
			case 'J' :
			case 'j' :
				return d + m + m + m;
			case 'K' :
			case 'k' :
				return m + d + m;
			case 'L' :
			case 'l' :
				return d + m + d + d;
			case 'M' :
			case 'm' :
				return m + m;
			case 'N' :
			case 'n' :
				return m + d;
			case 'O' :
			case 'o' :
				return m + m + m;
			case 'P' :
			case 'p' :
				return d + m + m;
			case 'Q' :
			case 'q' :
				return m + m + d + m;
			case 'R' :
			case 'r' :
				return d + m + d;
			case 'S' :
			case 's' :
				return d + d + d;
			case 'T' :
			case 't' :
				return m;
			case 'U' :
			case 'u' :
				return d + d + m;
			case 'V' :
			case 'v' :
				return d + d + d + m;
			case 'W' :
			case 'w' :
				return d + m + m;
			case 'X' :
			case 'x' :
				return m + d + d + m;
			case 'Y' :
			case 'y' :
				return m + d + m + m;
			case 'Z' :
			case 'z' :
				return m + d + d;

			case '0' :
				return m + m + m + m + m;
			case '1' :
				return d + m + m + m + m;
			case '2' :
				return d + d + m + m + m;
			case '3' :
				return d + d + d + m + m;
			case '4' :
				return d + d + d + d + m;
			case '5' :
				return d + d + d + d + d;
			case '6' :
				return m + d + d + d + d;
			case '7' :
				return m + m + d + d + d;
			case '8' :
				return m + m + m + d + d;
			case '9' :
				return m + m + m + m + d;

			case '.' :
				return d + m + d + m + d + m;
			case ',' :
				return m + m + d + d + m + m;
			case '?' :
				return d + d + m + m + d + d;
			case '!' :
				return d + d + m + m + d;
			case ':' :
				return m + m + m + d + d + d;
			case ';' :
				return m + d + m + d + m + d;
			case '\'' :
				return d + m + m + m + m + d;
			case '"' :
				return d + m + d + d + m + d;
			case '/' :
				return m + d + d + m + d;
			case '+' :
				return d + m + d + m + d;
			case '-' :
				return m + d + d + d + d + m;
			case '=' :
				return m + d + d + d + m;
			case '(' :
				return m + d + m + m + d;
			case ')' :
				return m + d + m + m + d + m;
			case '&' :
				return d + m + d + d + d;
			case '_' :
				return d + d + m + m + d + m;
			case '$' :
				return d + d + d + m + d + d + m;
			case '@' :
				return d + m + m + d + m + d;

		}
		return " ";
	}
}
